Proprietary JDBC drivers for databases like Oracle, IBM DB2, Microsoft SQL Server are not available on Maven Central repository.
Drivers should be downloaded manually and copied to this folder.