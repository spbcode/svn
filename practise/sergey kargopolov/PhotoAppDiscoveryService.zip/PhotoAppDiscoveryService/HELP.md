# Getting Started

### Guides
The following guides illustrates how to use certain features concretely:

* [Service Registration and Discovery](https://spring.io/guides/gs/service-registration-and-discovery/)

