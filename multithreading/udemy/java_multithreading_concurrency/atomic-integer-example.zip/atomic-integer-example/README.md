Code examples for the online course [Java Multithreading, Concurrency & Performance Optimization](https://www.udemy.com/java-multithreading-concurrency-performance-optimization)

Author : Michael Pogrebinsky

### To open the project using Intellij

1. File -> New -> "Project from Existing Sources" or "Import Project".
2. Select the project directory.
3. Select "Create Project from Existing Sources" and click "Next" repeatedly until the last window.
4. Click "Finish"



