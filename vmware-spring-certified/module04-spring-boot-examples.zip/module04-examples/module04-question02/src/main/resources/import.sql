insert into todo_item values(1, 'Export Data for HR');
insert into todo_item values(2, 'Send report to John');
insert into todo_item values(3, 'Specify requirements with PO');
insert into todo_item values(4, 'Review budget with PM');