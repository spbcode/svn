package com.spring.professional.exam.tutorial.module04.question23.auto.configuration.filestore;

public interface FileStore {
    void printFileStoreInfo();
}
