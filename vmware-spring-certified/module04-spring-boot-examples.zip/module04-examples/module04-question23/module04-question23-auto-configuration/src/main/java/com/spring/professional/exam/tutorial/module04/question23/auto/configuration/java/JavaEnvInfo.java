package com.spring.professional.exam.tutorial.module04.question23.auto.configuration.java;

public interface JavaEnvInfo {
    void printJvmEnvInfo();
}
