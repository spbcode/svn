package com.spring.professional.exam.tutorial.module04.question41.dao;

import com.spring.professional.exam.tutorial.module04.question41.ds.City;
import org.springframework.data.repository.CrudRepository;

public interface CityDao extends CrudRepository<City, Integer> {
}
