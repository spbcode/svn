package com.spring.professional.exam.tutorial.module04.question19.extra.service;

import org.springframework.stereotype.Service;

@Service
public class ServiceB {
}
