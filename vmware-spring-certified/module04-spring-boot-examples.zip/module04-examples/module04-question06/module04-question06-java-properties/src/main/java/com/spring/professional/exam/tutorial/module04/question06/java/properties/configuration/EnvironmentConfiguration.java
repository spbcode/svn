package com.spring.professional.exam.tutorial.module04.question06.java.properties.configuration;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class EnvironmentConfiguration {
    private String name;
    private String url;
}
